<body>
	<nav>
		<div class="logo">
			<h4>nouri</h4>
		</div>
		<ul class="nav-links">
			<li><a href="/">Home</a></li>
			<li><a href="/about">About</a></li>
		</ul>
	</nav>
    <div class="aboutText">
        <h4>What is "nouri"?</h4>
        <p>Our Nouri-Station enables everyone to perform an independent blood analysis at home. With this nutrient deficiencies can be detected and then corrected or prevented. The Nouri-App helps by creating awareness about nutrition.</p>
        <br>
        <h4>How does it work?</h4>
        <p>To find out which nutrients are in which food you can simply enter the name of the food you are interested in the search box and confirm with the Submit-Button. Nouri also shows what percentage of the daily requirement is covered by 100g? of the food.</p>
        <br>
        <h4>Have fun trying out your favourite foods!</h4>
    </div>
</body>