<script>
    import { each } from "svelte/internal";


	let query = "";
	let ingredients=[];

	
	async function queryFood(name) {
		const response = await fetch(
			'https://api.spoonacular.com/food/ingredients/search?query=' +
				name +
				'&number=1&apiKey=55b11bb5507a4957965c58c333eef263'
		);

		const responseBody = await response.json();
		return responseBody.results;
	};

	async function getNutrients(foods) {
		const response = await fetch(
			'https://api.spoonacular.com/food/ingredients/'+ foods.id +'/information?amount=1&apiKey=55b11bb5507a4957965c58c333eef263'
		);

		return await response.json();
	};
		

	async function handleClick() {
		const foods = await queryFood(query);
		console.log(foods);
		ingredients = [await getNutrients(foods[0])];
		console.log(ingredients);
;		
	}   

</script>
<body>
	<nav>
		<div class="logo">
			<h4>nouri</h4>
		</div>
		<ul class="nav-links">
			<li><a href="/">Home</a></li>
			<li><a href="/about">About</a></li>
		</ul>
	</nav>
	<div class="foodName">
		{#each ingredients as ingredient}
			<p class="foodInfoName">{ingredient.name}</p>
		{/each}
	</div>
	<div class="foodImage">
		{#each ingredients as ingredient}
				<img src={"https://spoonacular.com/cdn/ingredients_250x250/" + ingredient.image} alt="">
		{/each}
	</div>
	<div class="search">
		<input id="userInput" bind:value={query} placeholder=" Food"><button on:click={handleClick}>
		Submit
	</button>
	</div>
	<div class="foodInfo">
		<div class="foodInfoNutrient">
			{#each ingredients as ingredient}
				{#each ingredient.nutrition.nutrients as nutrient}
					<p>{`${nutrient.name}: ${nutrient.amount}${nutrient.unit}`}</p>
				{/each}
			{/each}
		</div>
		<div class="foodInfoDaily">
			{#each ingredients as ingredient}
				{#each ingredient.nutrition.nutrients as nutrient}
					<p>{`${nutrient.percentOfDailyNeeds}%`}</p>
				{/each}
			{/each}
		</div>
	</div>
</body>
<style>
</style>

