README:

    Seitenübergreifend gibt es oben eine Navigationsleiste auf der man zwischen den Seiten "Home" und "About" wechseln kann.

        Home:
            Auf der Home Seite gibt es ein Input Feld. Wenn man in dieses Input Feld den Namen eines Lebensmittels eingibt und mit dem rechts daneben liegenden "Submit" Buttons bestätigt erscheint über dem Input Feld der Name sowie ein 250x250px großes Bild des jeweiligen Lebensmittels. Unter dem Input Feld werden die Nährstoffe mit Namen, Menge, Einheit und Prozent des erfüllten Tagesbedarfs aufgelistet.

        About:
            Auf der About Seite wird der Zusammenhang mit meinem Invention Design Projekt erklärt, sowie der Funktionsumfang der Home Seite.